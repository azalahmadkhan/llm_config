# Images and Logos

![Dask logo](images/dask_icon.svg)

![Dask logo without padding](images/dask_icon_no_pad.svg)

![Dask logo](images/dask_horizontal.svg)

![Dask logo without padding](images/dask_horizontal_no_pad.svg)

![Dask logo](images/dask_horizontal_white.svg)

![Dask logo](images/dask_horizontal_white_no_pad.svg)

![Dask logo](images/dask_stacked.svg)

![Dask logo](images/dask_stacked_white.svg)

![HHMI Janelia logo](images/HHMI_Janelia_Color.png)
